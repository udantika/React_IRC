import '../Assets/Css/services1.css';

const Services1=()=>
{
    return(
    
<div>

 
<body className='bodys'>
  <div class="cardser1">
     <h2 className='h2ser1'>
     KPN Travels
     </h2>
     <p className='pser1'>
     As a leader in South India’s bus service providers, KPN Travels shines primarily in Tamil Nadu. Having been established in 1973, KPN Travels has seen considerable growth,extending its network across Tamil Nadu, Kerala.

     </p>
  </div>
  <div class="cardser1">
    <h2 className='h2ser1'>TNSTC</h2>
    <p className='pser1'>
    Tamil Nadu State Transport Corporation (TNSTC) is a public transportation company that provides comprehensive services across Tamil Nadu and neighboring states.
    Daily commuting or intercity travel, TNSTC is a trusted choice.
    </p>
  </div>
  <div class="cardser1">
    <h2 className='h2ser1'>Neetabus IN</h2>
    <p className='pser1'>
    Neeta Tours and Travels is a renowned travel company that has been providing high-quality bus services in various parts of India, including Tamil Nadu.
    This allows passengers to conveniently book their tickets from anywhere, anytime.
    </p>
  </div>
</body>
 

 </div>

    )
}
export default Services1;