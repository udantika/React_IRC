import '../Assets/Css/services.css';

const Services=()=>
{
    return(
    
<div>

<body className='bodyt'>
  <div class="cardser">
     <h2 className='h2ser'>
     KPN Travels
     </h2>
     <p className='pser'>
     As a leader in South India’s bus service providers, KPN Travels shines primarily in Tamil Nadu. Having been established in 1973, KPN Travels has seen considerable growth.

     </p>
  </div>
  <div class="cardser">
    <h2 className='h2ser'>TNSTC</h2>
    <p className='pser'>
    Tamil Nadu State Transport Corporation (TNSTC) is a public transportation company that provides comprehensive services across Tamil Nadu and neighboring states.
    </p>
  </div>
  <div class="cardser">
    <h2 className='h2ser'>Neetabus IN</h2>
    <p className='pser'>
    Neeta Tours and Travels is a renowned travel company that has been providing high-quality bus services in various parts of India, including Tamil Nadu.
    </p>
  </div>
</body>

 </div>

)
}
export default Services;