import '../Assets/Css/services.css';

const Services=()=>
{
    return(
    
<div>

<body className='bodyt'>
  <div class="card">
  </div>
  <div class="card">
  </div>
  <div class="card">
  </div>
</body>

 </div>

)
}
export default Services;