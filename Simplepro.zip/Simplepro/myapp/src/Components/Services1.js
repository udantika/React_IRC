import '../Assets/Css/services1.css';

const Services1=()=>
{
    return(
    
<div>
<div class="background">
  <img src="https://i.imgur.com/zQuIc9e.png" class="car"/>
  <img src="https://i.imgur.com/fk6LzHw.png" class="motorbike"/>
</div>
 

 

 </div>

    )
}
export default Services1;